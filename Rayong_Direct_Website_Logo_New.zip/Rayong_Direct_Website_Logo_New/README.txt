RAYONG DIRECT WEBSITE v3

This version fixes the broken logo/image problem by including:
assets/rayong-direct.jpg

IMPORTANT FOR GITHUB PAGES:
Upload ALL files and the assets folder. Do not upload only index.html and style.css.

Files:
- index.html
- preorder.html
- style.css
- CNAME
- assets/rayong-direct.jpg

GitHub Pages:
Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save

Custom domain:
Enter: rayongdirect.shop
Then Save. Keep Enforce HTTPS enabled after GitHub verifies the domain.

Contact:
Phone/WhatsApp: +66 6604 60200
Facebook: https://www.facebook.com/share/1MH38YdDNH/
LINE: 60460200
Viber: 0617533941
